-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2024 at 06:53 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb2`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `acno` varchar(50) NOT NULL,
  `pin` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` int(100) DEFAULT NULL,
  `amount` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`acno`, `pin`, `name`, `fname`, `gender`, `city`, `state`, `country`, `email`, `phone`, `amount`) VALUES
('SBI101', '123', 'Satyam', 'Mr.', 'm', 'india', 'UP', 'Dpr', 'satyamchauhan11114@gmail.com', 2147483647, 16061),
('SBI102', '1234', 'Satyam', 'Mr.', 'm', 'india', 'UP', 'Dpr', 'satyamchauhan11114@gmail.com', 2147483647, 18061),
('SBI103', '1234', 'Satyam', 'Mr.', 'm', 'india', 'UP', 'Dpr', 'satyamchauhan11114@gmail.com', 2147483647, 18061),
('SBI104', '1234', 'shivam', 'mr', 'male', 'india', 'up', 'dpr', 'shivam@gmail.com', 123654, 18061),
('SBI105', '1234', 'shivam', 'mr', 'male', 'india', 'up', 'dpr', 'shivam@gmail.com', 123654, 18061),
('SBI106', '1234', 'shiva', 'mr', 'male', 'india', 'Uttar Pradesh', 'DHAMPUR', 'shiva@gmail.com', 2147483647, 18061),
('SBI107', '1234', 'shiva1', 'mr', 'male', 'india', 'Uttar Pradesh', 'DHAMPUR', 'shiva1@gmail.com', 975997840, 18061);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `course` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `course`) VALUES
(1, 'Satyam rajput', 'gndjbnd'),
(4, 'vsfb', 'dbgtd'),
(5, 'jdfnknkdekvndnk', 'bnngkndjunkgtnd'),
(7, 'shivam', 'fjvbsd'),
(8, 'Satyam Chauhan', 'vnksvv'),
(9, 'Satyam Chauhan', 'vnksvv'),
(10, 'hjbhj', 'nuiu'),
(11, 'cdj', 'aksa'),
(12, 'cdj', 'aksa'),
(13, 'hbj', 'hbjk'),
(14, 'Anuj', 'India'),
(15, 'kbjj', 'njk'),
(23, 'kbjjvsdkviusndkds', 'njk'),
(25, 'Satyam gvthyyh', 'gndjbndyuhgyugyug');

-- --------------------------------------------------------

--
-- Table structure for table `uinfo`
--

CREATE TABLE `uinfo` (
  `uname` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `uinfo`
--

INSERT INTO `uinfo` (`uname`, `pass`, `email`, `phone`) VALUES
('anuj', '123', 'anuj@gmail.com', '15154646'),
('anujvhfbshjv', '123', 'anuj@gmail.com', '15154646'),
('anujvhfbshjvfjvhnkusnkvjrfkk', '123', 'anufnsdjkvjj@gmail.com', '15154646'),
('satyam', '1234', 'satyam@gmail.com', '9759978409'),
('Shiavm', '1234', 'satyamchauhan11114@gmail.com', '123456789'),
('Shiavm1', '1234', 'satyamchauhan11114@gmail.com', '123456789'),
('shiva', '1234', 'shiva@gmail.com', '789456123'),
('shiva1', '1234', 'shiva@gmail.com', '789456123'),
('v n', '123', 'satyamrajput643@gmail.com', '09759978409'),
('xxdjk', 'ajbjkd', 'dbvjksb@gmail.com', '454894846'),
('zbchjs', 'vjksnk', 'vsklnvkjns@gmail.com', '151466516');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'Anuj', 'anuj@gmail.com', '12345', '2024-03-20 00:19:17', '2024-03-20 00:19:17'),
(2, 'Anuj', 'anuj001@gmail.com', '12345', NULL, NULL),
(3, 'satyam', 'satyam@gmail.com', '123456', NULL, NULL),
(4, 'Satyam Chauhan', 'satyamrajput643@gmail.com', '12345', '2024-03-20 00:27:52', '2024-03-20 00:27:52'),
(6, 'Satyam Chauhan', 'satyamrajput43@gmail.com', '1234', NULL, NULL),
(8, 'Satyam Chauhan', 'satyamr43@gmail.com', '123', NULL, NULL),
(9, 'Satyam Chauhan', 'anuj555@gmail.com', '123', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`acno`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uinfo`
--
ALTER TABLE `uinfo`
  ADD PRIMARY KEY (`uname`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
